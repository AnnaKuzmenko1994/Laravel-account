@extends('layouts.master')

@section('content')
  <h1>Laravel</h1>
@endsection
